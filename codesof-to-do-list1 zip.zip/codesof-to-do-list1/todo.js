const inputBox = document.getElementById("input-box");
const listStyle = document.getElementById("list-style");

function addtask() {
    if (inputBox.value === '') {
        alert("You must add some task");
    } else {
        let li = document.createElement("li");
        li.innerHTML = inputBox.value;
        listStyle.appendChild(li);

        let span = document.createElement("span");
        span.innerHTML = "\u00d7";
        li.appendChild(span);
    }
    inputBox.value = '';
    saveList();
}

listStyle.addEventListener("click", function (e) {
    if (e.target.tagName === "LI") {
        e.target.classList.toggle("checked");
        saveData();
    } else if (e.target.tagName === "SPAN") {
        e.target.parentNode.remove();
        saveData();
    }
}, false);

function saveData() {
    localStorage.setItem("data", listStyle.innerHTML);
}

function showList() {
    listStyle.innerHTML = localStorage.getItem("data");
}
showList();
